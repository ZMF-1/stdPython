You can import all Python built-in packages through this package.
</br>
[github](https://github.com/ZMF-1/stdPython)
</br>
### How to install
```commandline
pip install stdPython
```
### How to get the document
```python
from stdPython import *
help.help()
```