# -*- coding: utf-8 -*-
# @Time    : 2023/11/28 21:12:56
# @Author  : ZMF
# @FileName: information.py
# @Software: PyCharm
# @IDE: PyCharm
# @E-Mail: ZZMF20110806@163.com
author = 'ZMF'
version = 'V1.0.0'
pack_name = 'stdPython'
help_file = 'help.py'
files = ['__init__.py', 'information.py', 'help.py']